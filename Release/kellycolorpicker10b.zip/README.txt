﻿Установка:

1. Распаковать архив 

2. Если установлено приложение "Adode Extension Manager" то запустить файл KellyColorPicker.zxp и следовать инструкциям
установщика игнорируя предупреждения.

Если не установлено то скопировать папку "KellyColorPicker" в папку с расширениями (создать папку если она отсутствует)

для Photoshop 2015 и более новых версий

C:\Program Files (x86)\Common Files\Adobe\CEP\extensions

для старых версий Photoshop

C:\Program Files (x86)\Common Files\Adobe\CEPServiceManager4\extensions